export const firebaseConfig = {
};